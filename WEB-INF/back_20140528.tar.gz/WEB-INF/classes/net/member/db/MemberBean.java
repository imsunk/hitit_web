package net.member.db;

public class MemberBean {
	private String M_ID;
	private String M_PW;
	private String M_NAME;
	private int M_AGE;
	private String M_GENDER;
	private String M_EMAIL;
	
	public String getM_ID() {
		return M_ID;
	}
	public void setM_ID(String member_id) {
		M_ID = member_id;
	}
	public String getM_PW() {
		return M_PW;
	}
	public void setM_PW(String member_pw) {
		M_PW = member_pw;
	}
	public String getM_NAME() {
		return M_NAME;
	}
	public void setM_NAME(String member_name) {
		M_NAME = member_name;
	}
	public int getM_AGE() {
		return M_AGE;
	}
	public void setM_AGE(int member_age) {
		M_AGE = member_age;
	}
	public String getM_GENDER() {
		return M_GENDER;
	}
	public void setM_GENDER(String member_gender) {
		M_GENDER = member_gender;
	}
	public String getM_EMAIL() {
		return M_EMAIL;
	}
	public void setM_EMAIL(String member_email) {
		M_EMAIL = member_email;
	}
}
