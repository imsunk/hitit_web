// Activates the Carousel
$('.carousel').carousel({
  interval: 5000
})

// Activates Tooltips for Social Links
$('.tooltip-social').tooltip({
  selector: "a[data-toggle=tooltip]"
})

// bind

$('#loginForm').ready(function () {
	var login =  function (e) {
		var id = document.getElementById("id").value;
		var pw = document.getElementById("pw").value;
		if(e.keyCode==13){
			$.ajax({
				url: "http://hitit.chonbuk.ac.kr:8080/hitit_w/ajax_login.jsp",
				type: "POST",
				data: { "id": id , "pw":pw },   
				dataType: "text",
				contentType: "application/text; charset=utf-8",
				success: function (response) {
					if(response == 1){
						console.log("로그인 성공");
						$("#loginForm").parent()[0].innerHTML = "<a href>"+ response+" 님이 로그인 하셨습니다. [ 내 정보 ]";
					} else {
						console.log("로그인 실패");
					}
				},
				error: function (response) {
					console.log("통신자체가 안됨 서버에러");
				}
			});
		}
	}

	$("#id").bind("keypress", login);
	$("#pw").bind("keypress", login);

});

function modifyboard(){
	modifyform.submit();
}

function replyboard(){
	boardform.submit();
}

function addboard(){
	boardform.submit();
}

