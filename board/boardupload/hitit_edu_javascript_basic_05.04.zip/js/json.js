/**
 * @author HITIT_EDU
 */
/* JSON - Javascript Object Notation*/
$(function(){
   var object1 = {
      name: 'kimSeonHo',
      phone: '010-3800-2109'
   }
   
   var json1 = JSON.stringify(object1);
   var java1 = JSON.parse(json1);
   
   document.writeln('json = ' + json1);
   document.writeln('javascript = ' + java1.name);
   document.writeln('javascript = ' + java1.phone);

   })