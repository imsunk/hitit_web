//학생 정보 배열 추가
var students = [];
students.push({ 이름: '김선호', C: 99});
students.push({ 이름: '김선호', D: 95});
students.push({ 이름: '김선호', E: 92});